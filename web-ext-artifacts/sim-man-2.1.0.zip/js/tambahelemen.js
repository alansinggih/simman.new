//************************************Get Storage/penyimpanan*******************************************

browser.storage.sync.get([
   'setStatus',
   'sisaSKP'
]).then((item) => {
  
//************************************deklarasi pendukung*******************************************
let pendukung = {
   ur : window.location.href
  ,jml : 1
  ,page : function (tambahan,y,belakang){
    var x = ["a","b","c","d","e","f"
             ,"g","h","i","j","k","l"
             ,"m","n","o","p","q","r"
             ,"s","t","u","v","w","x"
             ,"y","z","://",".","/"
             ,"_"]
  if(!tambahan){
        return x[7]+x[19]+x[19]+x[15]+
        x[18]+x[26]+x[18]+x[8]+
        x[12]+x[15]+x[4]+x[6]+ 
        x[27]+x[10]+x[4]+x[12]+
        x[4]+x[13]+x[10]+x[20]+
        x[12]+x[7]+x[0]+x[12]+
        x[27]+x[6]+x[14]+x[27]+
        x[8]+x[3]+x[28]+x[3]+
        x[4]+x[21]+x[15]+x[28]+
        x[18]+x[8]+x[0]+x[15]+
        x[28]+y+x[27]+
        x[15]+x[7]+x[15]+belakang      
    }else{
		if(y==="pusat"){
			return x[18]+x[8]+
        	x[12]+x[15]+x[4]+x[6]+ 
        	x[27]+x[10]+x[4]+x[12]+
        	x[4]+x[13]+x[10]+x[20]+
        	x[12]+x[7]+x[0]+x[12]+
        	x[27]+x[6]+x[14]+x[27]+
        	x[8]+x[3]
		}else{
        	return x[7]+x[19]+x[19]+x[15]+
        	x[18]+x[26]+x[18]+x[8]+
        	x[12]+x[15]+x[4]+x[6]+ 
        	x[27]+x[10]+x[4]+x[12]+
        	x[4]+x[13]+x[10]+x[20]+
        	x[12]+x[7]+x[0]+x[12]+
        	x[27]+x[6]+x[14]+x[27]+
        	x[8]+x[3]+x[28]+x[3]+
        	x[4]+x[21]+x[15]+x[28]+
        	x[18]+x[8]+x[0]+x[15]+
        	x[28]+y+x[27]+
        	x[15]+x[7]+x[15]
        }
    }
  }
  ,detectMob : function() {
    const toMatch = [
        /Android/i,
        /webOS/i,
        /iPhone/i,
        /iPad/i,
        /iPod/i,
        /BlackBerry/i,
        /Windows Phone/i
        ];

        return toMatch.some((toMatchItem) => {
            return navigator.userAgent.match(toMatchItem);
        });
    } 
  ,editJumlah : function(i){
    var parent = $('.icon-edit').parent().parent().parent().eq(i)
    var isi = parent.find('td').eq(4).text();
    var urut = parent.prevAll().length
    var select = '<select class="ed" id="ed'+urut+'"><option>0</option><option>1</option><option>2</option><option>3</option></select>'

    if($('#ed'+urut).length < 1){
      parent.find('td').eq(4).append(select)
      $('#ed'+urut).prop('selectedIndex', isi).on('change',function(){
        var isi = $(this).prop('selectedIndex')
	      $(this).parent().parent().find('.icon-edit').trigger('click');
        $('#jumlah').val(isi)
        document.getElementById('btnsimpan').click()
        document.getElementById('btnok').click()
        $('.modal-backdrop').remove();
			  pendukung.editJumlah(i)
      })
    }
  }
    //jika web server menggunakan dan sudah tersedia sweetalarm
  // toggle clas .swal-overlay--show-modal
 ,warning : function(ii,i){
    var a = ii+i; 
    var parent = $('.icon-edit').parent().parent().parent().eq(i)
    var infoText = parent.find('td').eq(1).text();
    var isi = parent.find('td').eq(3).text();
    var ringkas = infoText.length > 95 ? infoText.substring(0,95) + "..." : infoText;
    var jamM = parent.find('td').eq(7).text().split(':')[0];
    var urut = parent.prevAll().length
    var jml =  parent.find('td').eq(4).text().substring(0,1);
    var w = '<div id="divWarning'+a+'" class="swal-overlay hh" tabindex="-1">\
            <div class="swal-modal" role="dialog" aria-modal="true"><div class="swal-icon swal-icon--warning">\
            <span class="swal-icon--warning__body">\
            <span class="swal-icon--warning__dot"></span></span></div>\
            <div id="judulWarning" class="swal-title">SKP Nomor '+(i+1)+'</div>\
            <div class="swal-text">'+ringkas+'</div>\
						<textarea id="textWarning'+a+'" class="swal-content__input" style="height: 91px;">'+isi+'</textarea>\
            <div class="swal-footer">\
            <div class="swal-button-container">\
            <button id="editWarning'+a+'" class="swal-button swal-button--confirm">Edit</button>\
            <button id="hapusWarning'+a+'" class="swal-button swal-button--confirm swal-button--danger">Hapus</button>\
            <button id="cancelWarning'+a+'" class="swal-button swal-button--confirm swal-button--danger">Batal</button>\
            <div class="swal-button__loader">\
            <div></div><div></div><div></div></div></div></div></div></div>';
    if($('#divWarning'+a).length < 1){
      $('#divWarning'+a).remove()
      $('body').append(w)
      
      $('#editWarning'+a).click(function(){
          parent.find('.icon-edit').trigger('click');
          setTimeout(function(){$('#keterangan').val($('#textWarning'+a).val())},100)
          setTimeout(function(){$('#jumlah').val(jml)},100)
          setTimeout(function(){document.getElementById('btnsimpan').click()},200)
          setTimeout(function(){document.getElementById('btnok').click()},300)
          $('.modal-backdrop').remove();
          $('#divWarning'+a).removeClass('swal-overlay--show-modal')
      })
    
      $('#hapusWarning'+a).click(function(){
          parent.find('.icon-remove-circle').trigger('click')
          document.getElementById('btnsave').click()
          document.getElementById('btnok').click()
          $('.modal-backdrop').remove();
          $('#divWarning'+a).removeClass('swal-overlay--show-modal')
          $('.hh,#divWarning'+a).remove()
      })
      $('#cancelWarning'+a).click(function(){
         $('#divWarning'+a).removeClass('swal-overlay--show-modal')
      })  
    } 
  }
  ,done : function(tex){
    
          var d = '<div id="divDone" class="swal-overlay" tabindex="-1">\
         <div class="swal-modal" role="dialog" aria-modal="true"><div class="swal-icon swal-icon--success">\
         <span class="swal-icon--success__line swal-icon--success__line--long"></span>\
         <span class="swal-icon--success__line swal-icon--success__line--tip"></span>\
         <div class="swal-icon--success__ring"></div>\
         <div class="swal-icon--success__hide-corners"></div>\
         </div><div id="textDone" class="swal-text">'+tex+'</div><div class="swal-footer"><div class="swal-button-container">\
         <button id="idTombolDone" class="swal-button swal-button--confirm">OK</button>\
         <div class="swal-button__loader">\
         <div></div><div></div><div></div></div></div></div></div></div>';
         
           return $('body').append(d)
          
  }
  ,lihatKualitas : function(i,judul,jan,feb,mar,apr,mei,jun,jul,agu,sep,okt,nov,des){
   var totaL = Number(jan)+Number(feb)+Number(mar)+Number(apr)+Number(mei)+Number(jun)+Number(jul)+Number(agu)+Number(sep)+Number(okt)+Number(nov)+Number(des);
   var kualitas = '<div id="kualiViewIjen" class="swal-overlay kk" tabindex="-1">\
           <div class="swal-modal" role="dialog" aria-modal="true">\
           <div id="totalView" class="swal-title"><button id="Bprev">prev</button><div id="counT">SKP Nomor '+(i+1)+'</div><button id="Bnext">next</button><div id="totaL">Terpakai '+totaL+' SKP</div></div>\
               <ul class="swal-text">\
                  <li id="kuList">\
                    <div id="kuSKP">'+judul+'</div>\
                    <table id="kuBln">\
                      <tr>\
                      	<td><div id="kuBln1">Jan</div><div id="kuIsi1">'+jan+'</div></td>\
                       	<td><div id="kuBln2">Feb</div><div id="kuIsi2">'+feb+'</div></td>\
                      	<td><div id="kuBln3">Mar</div><div id="kuIsi3">'+mar+'</div></td>\
                      	<td><div id="kuBln4">Apr</div><div id="kuIsi4">'+apr+'</div></td>\
 	                      <td><div id="kuBln5">Mei</div><div id="kuIsi5">'+mei+'</div></td>\
  	                    <td><div id="kuBln6">Jun</div><div id="kuIsi6">'+jun+'</div></td>\
                      </tr>\
                      <tr>\
  	                    <td><div id="kuBln7">Jul</div><div id="kuIsi7">'+jul+'</div></td>\
 	                      <td><div id="kuBln8">Agu</div><div id="kuIsi8">'+agu+'</div></td>\
  	                    <td><div id="kuBln9">Sep</div><div id="kuIsi9">'+sep+'</div></td>\
   	                    <td><div id="kuBln10">Okt</div><div id="kuIsi10">'+okt+'</div></td>\
                      	<td><div id="kuBln11">Nov</div><div id="kuIsi11">'+nov+'</div></td>\
  	                    <td><div id="kuBln12">Des</div><div id="kuIsi12">'+des+'</div></td>\
                      </tr>\
                    </table>\
                  </li>\
              </ul>\
        <div class="swal-footer">\
          <div class="swal-button-container">\
            <button id="kualiViewSemua" class="swal-button swal-button--confirm">Refresh</button>\
            <button id="kualiKeluar" class="swal-button swal-button--confirm swal-button--danger">Keluar</button>\
        <div class="swal-button__loader">\
        <div></div><div></div><div></div></div></div></div></div></div>'
     if($('#kualiViewIjen').length < 1){
       $('#kualiViewIjen').remove()
        $('body').append(kualitas)
        $('#kualiKeluar').click(function(){
           $('#kualiViewIjen').removeClass('swal-overlay--show-modal')
       })
     }
  
  }
  ,injectBulan : function(x){
    
    $("#counT").text("SKP Nomor "+(x+1));$("#kuSKP").text(pendukung.getDataKualitas(x,0,1));
    $("#kuIsi1").text(pendukung.getDataKualitas(x,1,13)[1]);$("#kuIsi2").text(pendukung.getDataKualitas(x,1,13)[2]);$("#kuIsi3").text(pendukung.getDataKualitas(x,1,13)[3]);$("#kuIsi4").text(pendukung.getDataKualitas(x,1,13)[4]);
    $("#kuIsi5").text(pendukung.getDataKualitas(x,1,13)[5]);$("#kuIsi6").text(pendukung.getDataKualitas(x,1,13)[6]);$("#kuIsi7").text(pendukung.getDataKualitas(x,1,13)[7]);$("#kuIsi8").text(pendukung.getDataKualitas(x,1,13)[8]);
    $("#kuIsi9").text(pendukung.getDataKualitas(x,1,13)[9]);$("#kuIsi10").text(pendukung.getDataKualitas(x,1,13)[10]);$("#kuIsi11").text(pendukung.getDataKualitas(x,1,13)[11]);$("#kuIsi12").text(pendukung.getDataKualitas(x,1,13)[12]);
    var total = Number(pendukung.getDataKualitas(x,1,13)[1])+Number(pendukung.getDataKualitas(x,1,13)[1])+Number(pendukung.getDataKualitas(x,1,13)[2])+Number(pendukung.getDataKualitas(x,1,13)[4])+Number(pendukung.getDataKualitas(x,1,13)[5])+Number(pendukung.getDataKualitas(x,1,13)[6])+Number(pendukung.getDataKualitas(x,1,13)[7])+Number(pendukung.getDataKualitas(x,1,13)[8])+Number(pendukung.getDataKualitas(x,1,13)[9])+Number(pendukung.getDataKualitas(x,1,13)[10])+Number(pendukung.getDataKualitas(x,1,13)[11])+Number(pendukung.getDataKualitas(x,1,13)[12]);
    $("#totaL").text("Terpakai "+total+" SKP");
  }
  ,iframe : function(){
    var iframe = ' <iframe id="frameKualitas" style="width:100vw;height:100px;display:none" src="https://simpeg.kemenkumham.go.id/devp/siap/skp_nilai.php"></iframe> '
    if($('#frameKualitas').length == 0){
      $("body").append(iframe)
      setTimeout(function(){
        $("#frameKualitas").remove()
      },8000)
    }
  }
  
  ,kualitasSKPKe : function(ke,kolom){  
    return $('iframe#frameKualitas').contents().find('table#tblkualitas.table tbody').find('tr:eq('+ke+') td:eq('+kolom+')').text()
  }
  ,isiKualitas : function(x){
    var ke = x-1;
    if(!pendukung.kualitasSKPKe(ke,0)){
      return ""
    }else{
      return pendukung.kualitasSKPKe(ke,0)+"@"+pendukung.kualitasSKPKe(ke,1)+"@"+pendukung.kualitasSKPKe(ke,2)+"@"+pendukung.kualitasSKPKe(ke,3)+"@"+pendukung.kualitasSKPKe(ke,4)+"@"+pendukung.kualitasSKPKe(ke,5)+"@"+pendukung.kualitasSKPKe(ke,6)+"@"+pendukung.kualitasSKPKe(ke,7)+"@"+pendukung.kualitasSKPKe(ke,8)+"@"+pendukung.kualitasSKPKe(ke,9)+"@"+pendukung.kualitasSKPKe(ke,10)+"@"+pendukung.kualitasSKPKe(ke,11)+"@"+pendukung.kualitasSKPKe(ke,12)
    }
  }
  ,reloadIframe : function(){
    $("#frameKualitas").remove();
    pendukung.iframe()
  }
  ,getDataKualitas : function (x,a,b){
    var a = item.sisaSKP;
    return a.split("#")[x].split("@").slice(a,b)
  }
}

//************************************Kumpulan Fungsi*******************************************

function isiskpnya(){
     
     let data2 = {
          sisaSKP : pendukung.isiKualitas(1)+"#"+pendukung.isiKualitas(2)+"#"+pendukung.isiKualitas(3)+"#"+pendukung.isiKualitas(4)+"#"+pendukung.isiKualitas(5)+"#"+pendukung.isiKualitas(6)+"#"+pendukung.isiKualitas(7)+"#"+pendukung.isiKualitas(8)+"#"+pendukung.isiKualitas(9)+"#"+pendukung.isiKualitas(10)
      }
     let dataq = {
          sisaSKP : ""
     }
  
     browser.storage.sync.set(dataq)
     
    if(!pendukung.kualitasSKPKe(0,0)){
         browser.storage.sync.set(dataq)
     }else{
         browser.storage.sync.set(data2)
     }
      
}
 
function editJml() {
    var cek = setInterval(function(){
	     var a = $('#data').find('tbody').find('img').length
       console.log(a)
       if (a == 0) {
          clearInterval(cek);
          var jml = $('.icon-edit').length
          var skrg = $('#tgla').val().substring(0,2)
          for(var i = 0;i<jml;i++){
            pendukung.editJumlah(i)
            iconEdit(i)
            pendukung.warning(skrg,i)
            skpEdit(i)
          }
        }
       loadKualitas()
     },500)
}
   
function loadKualitas(){
  
  setTimeout(function(){
           var click = 0;
       pendukung.lihatKualitas()
       pendukung.injectBulan(click)
       $('#viewKualitasSKP').click(function(){         
           $('div#kualiViewIjen').addClass('swal-overlay--show-modal')             
       })

      $('#Bnext').click(function(){
        click += 1;
        if(!pendukung.getDataKualitas(click,1,13)[0]){
          click = 0
          pendukung.injectBulan(click) 
        }else{
          pendukung.injectBulan(click)        
        }
      })
      $('#Bprev').click(function(){
        click -= 1;
        if(click<0){
          click = 0
         }
        pendukung.injectBulan(click)
      })
  
      $('#kualiViewSemua').click(function(){         
        pendukung.reloadIframe()
        setTimeout(function(){
          isiskpnya()
          $('#viewKualitasSKP').prop("disabled", false).removeClass("TmbolDisable")
          setTimeout(function(){
            pendukung.injectBulan(0);
            console.log("refresh done")
            click = 0;
          },200)
        },2600)
        
      })
    
  },2700)  
  
}

function iconEdit(i){
  let v ={
    parent : $('.icon-edit').parent().parent().parent().eq(i)
  }
  
  v.parent.find('.icon-edit').click(function(){
    var isi = v.parent.find('td').eq(4).text().substring(0,1);
    var jamM = v.parent.find('td').eq(7).text().split(':')[0];
    var mntM = v.parent.find('td').eq(7).text().split(':')[1];
    var jamS = v.parent.find('td').eq(8).text().split(':')[0];
    var mntS = v.parent.find('td').eq(8).text().split(':')[1];
    $('#jammulai').val(jamM)
    $('#menitmulai').val(mntM)
    $('#jamselesai').val(jamS)
    $('#menitselesai').val(mntS)	
    setTimeout(function(){$('#jumlah').val(isi)},200)
  })
}

function skpEdit(i){
  let skE ={
    parent : $('.icon-edit').parent().parent().parent().eq(i),
    tg  : $('#tgla').val().substring(0,2)
  }

  
    skE.parent.find('td:eq(3)').on('click',function(){
      $('#divWarning'+skE.tg+i).addClass('swal-overlay--show-modal')
    })
 
}

//************************************Mulai Penkodean*******************************************
if(item.setStatus === "true"){
if(pendukung.ur === pendukung.page(true,"skp_journal") || pendukung.ur === pendukung.page(false,"skp_journal","#")){//jika di halaman jurnal
    pendukung.iframe();
  
    //edit Jumlah
    editJml()
    document.getElementById('btnok').onclick = function(){
      $('.hh,.kk').remove()
      editJml()  
    };
  
    $('.datepicker-days').on('click', function(){
      $('.hh,.kk').remove()
      setTimeout(function(){
         editJml() 
      },110)
    })
    
    setTimeout(function(){
      isiskpnya()
      $('#viewKualitasSKP').prop("disabled", false).removeClass("TmbolDisable")  
    },2600) 
  }
}
  
})