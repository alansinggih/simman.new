function saveOptions(e) {

    // prefs object
    let data = {
        setStatus : document.querySelector('#setStatus').value  || 'true'
        ,setMode : document.querySelector('#setMode').value  || 'penjagaan'
        ,setNIP    : document.querySelector('#setNIP').value    || ''
        ,setPass : document.querySelector('#setPass').value || ''
        ,setJamPagi : document.querySelector('#setJamPagi').value || ''
        ,setJamSiang : document.querySelector('#setJamSiang').value || ''
        ,setJamMalam : document.querySelector('#setJamMalam').value || ''
        ,codeSKP : document.querySelector('#codeSKP').value || ''
        ,setSKP1 : document.querySelector('#setSKP1').value || ''
        ,setSKP2 : document.querySelector('#setSKP2').value || ''
        ,setSKP3 : document.querySelector('#setSKP3').value || ''
        ,setSKP4 : document.querySelector('#setSKP4').value || ''
        ,setSKP5 : document.querySelector('#setSKP5').value || ''
        ,setSKP6 : document.querySelector('#setSKP6').value || ''
        ,setSKP7 : document.querySelector('#setSKP7').value || ''
        ,setSKP8 : document.querySelector('#setSKP8').value || ''
        ,setSKP9 : document.querySelector('#setSKP9').value || ''
        ,setSKP10 : document.querySelector('#setSKP10').value || ''
        ,setSKP11 : document.querySelector('#setSKP11').value || ''
        ,setSKP12 : document.querySelector('#setSKP12').value || ''
        ,setSKP13 : document.querySelector('#setSKP13').value || ''
        ,setSKP14 : document.querySelector('#setSKP14').value || ''
        ,setSKP15 : document.querySelector('#setSKP15').value || ''
        ,setSKP16 : document.querySelector('#setSKP16').value || ''
        ,setSKP17 : document.querySelector('#setSKP17').value || ''
        ,setSKP18 : document.querySelector('#setSKP18').value || ''
        ,setSKP19 : document.querySelector('#setSKP19').value || ''
        ,setSKP20 : document.querySelector('#setSKP20').value || ''
        
        
    }

    browser.storage.sync.set(data);

    // reload prefs
    browser.runtime.getBackgroundPage().then((item) => {
        item.simMan.loadData(function(){
            // refresh options
            restoreOptions();
            
        });
        
    });
    rubahH1()
    mode()
    e.preventDefault();    
    browser.tabs.query({currentWindow: true, active: true}).then((tabs) => {
        let tab = tabs[0]; // Safe to assume there will only be one result
        console.log(tab.url);
        browser.tabs.update({url: ''+tab.url+''})
        window.close()
    }, console.error), 

    window.close()
    
    
}

function restoreOptions() {
    browser.storage.sync.get('setStatus').then((item) => {
        document.querySelector('#setStatus').value = item.setStatus || '';
    });
    browser.storage.sync.get('setMode').then((item) => {
        document.querySelector('#setMode').value = item.setMode || '';
    });
    browser.storage.sync.get('setNIP').then((item) => {
        document.querySelector('#setNIP').value = item.setNIP || '';
    });
    browser.storage.sync.get('setPass').then((item) => {
        document.querySelector('#setPass').value = item.setPass || '';
    });
    browser.storage.sync.get('setJamPagi').then((item) => {
        document.querySelector('#setJamPagi').value = item.setJamPagi || '';
    });
    browser.storage.sync.get('setJamSiang').then((item) => {
        document.querySelector('#setJamSiang').value = item.setJamSiang || '';
    });
    browser.storage.sync.get('setJamMalam').then((item) => {
        document.querySelector('#setJamMalam').value = item.setJamMalam || '';
    });
    browser.storage.sync.get('codeSKP').then((item) => {
        document.querySelector('#codeSKP').value = item.codeSKP || '';
    });
    browser.storage.sync.get('setSKP1').then((item) => {
        document.querySelector('#setSKP1').value = item.setSKP1 || '';
    });
    browser.storage.sync.get('setSKP2').then((item) => {
        document.querySelector('#setSKP2').value = item.setSKP2 || '';
    });
    browser.storage.sync.get('setSKP3').then((item) => {
        document.querySelector('#setSKP3').value = item.setSKP3 || '';
    });
    browser.storage.sync.get('setSKP4').then((item) => {
        document.querySelector('#setSKP4').value = item.setSKP4 || '';
    });
    browser.storage.sync.get('setSKP5').then((item) => {
        document.querySelector('#setSKP5').value = item.setSKP5 || '';
    });
    browser.storage.sync.get('setSKP6').then((item) => {
        document.querySelector('#setSKP6').value = item.setSKP6 || '';
    });
    browser.storage.sync.get('setSKP7').then((item) => {
        document.querySelector('#setSKP7').value = item.setSKP7 || '';
    });
    browser.storage.sync.get('setSKP8').then((item) => {
        document.querySelector('#setSKP8').value = item.setSKP8 || '';
    });
    browser.storage.sync.get('setSKP9').then((item) => {
        document.querySelector('#setSKP9').value = item.setSKP9 || '';
    });
    browser.storage.sync.get('setSKP10').then((item) => {
        document.querySelector('#setSKP10').value = item.setSKP10 || '';
    });
    browser.storage.sync.get('setSKP11').then((item) => {
        document.querySelector('#setSKP11').value = item.setSKP11 || '';
    });
    browser.storage.sync.get('setSKP12').then((item) => {
        document.querySelector('#setSKP12').value = item.setSKP12 || '';
    });
    browser.storage.sync.get('setSKP13').then((item) => {
        document.querySelector('#setSKP13').value = item.setSKP13 || '';
    });
    browser.storage.sync.get('setSKP14').then((item) => {
        document.querySelector('#setSKP14').value = item.setSKP14 || '';
    });
    browser.storage.sync.get('setSKP15').then((item) => {
        document.querySelector('#setSKP15').value = item.setSKP15 || '';
    });
    browser.storage.sync.get('setSKP16').then((item) => {
        document.querySelector('#setSKP16').value = item.setSKP16 || '';
    });
    browser.storage.sync.get('setSKP17').then((item) => {
        document.querySelector('#setSKP17').value = item.setSKP17 || '';
    });
    browser.storage.sync.get('setSKP18').then((item) => {
        document.querySelector('#setSKP18').value = item.setSKP18 || '';
    });
    browser.storage.sync.get('setSKP19').then((item) => {
        document.querySelector('#setSKP19').value = item.setSKP19 || '';
    });
    browser.storage.sync.get('setSKP20').then((item) => {
        document.querySelector('#setSKP20').value = item.setSKP20 || '';
    });
    
    
    browser.storage.sync.get('setLabel0').then((item) => {
        document.querySelector('#setLabel0').innerHTML = item.setLabel0 || '';
    });
        browser.storage.sync.get('setLabel1').then((item) => {
        document.querySelector('#setLabel1').innerHTML = item.setLabel1 || '';
    });
        browser.storage.sync.get('setLabel2').then((item) => {
        document.querySelector('#setLabel2').innerHTML = item.setLabel2 || '';
    });
        browser.storage.sync.get('setLabel3').then((item) => {
        document.querySelector('#setLabel3').innerHTML = item.setLabel3 || '';
    });
        browser.storage.sync.get('setLabel4').then((item) => {
        document.querySelector('#setLabel4').innerHTML = item.setLabel4 || '';
    });
        browser.storage.sync.get('setLabel5').then((item) => {
        document.querySelector('#setLabel5').innerHTML = item.setLabel5 || '';
    });
        browser.storage.sync.get('setLabel6').then((item) => {
        document.querySelector('#setLabel6').innerHTML = item.setLabel6 || '';
    });
        browser.storage.sync.get('setLabel7').then((item) => {
        document.querySelector('#setLabel7').innerHTML = item.setLabel7 || '';
    });
        browser.storage.sync.get('setLabel8').then((item) => {
        document.querySelector('#setLabel8').innerHTML = item.setLabel8 || '';
    });
        browser.storage.sync.get('setLabel9').then((item) => {
        document.querySelector('#setLabel9').innerHTML = item.setLabel9 || '';
    });
        browser.storage.sync.get('setLabel10').then((item) => {
        document.querySelector('#setLabel10').innerHTML = item.setLabel10 || '';
    });
        browser.storage.sync.get('setLabel1').then((item) => {
        document.querySelector('#setLabel11').innerHTML = item.setLabel11 || '';
    });
        browser.storage.sync.get('setLabel12').then((item) => {
        document.querySelector('#setLabel12').innerHTML = item.setLabel12 || '';
    });
        browser.storage.sync.get('setLabel13').then((item) => {
        document.querySelector('#setLabel13').innerHTML = item.setLabel13 || '';
    });
        browser.storage.sync.get('setLabel14').then((item) => {
        document.querySelector('#setLabel14').innerHTML = item.setLabel14 || '';
    });
        browser.storage.sync.get('setLabel15').then((item) => {
        document.querySelector('#setLabel15').innerHTML = item.setLabel15 || '';
    });
        browser.storage.sync.get('setLabel16').then((item) => {
        document.querySelector('#setLabel16').innerHTML = item.setLabel16 || '';
    });
        browser.storage.sync.get('setLabel17').then((item) => {
        document.querySelector('#setLabel17').innerHTML = item.setLabel17 || '';
    });
        browser.storage.sync.get('setLabel18').then((item) => {
        document.querySelector('#setLabel118').innerHTML = item.setLabel18 || '';
    });
        browser.storage.sync.get('setLabel19').then((item) => {
        document.querySelector('#setLabel19').innerHTML = item.setLabel19 || '';
    });
        browser.storage.sync.get('infoCodeSKP').then((item) => {
        document.querySelector('#infoCodeSKP').innerHTML = item.infoCodeSKP || '';
    });

    rubahH1()
    mode()
}

function tabDone(evt, kategori) {
   var i, tabcontent, tablinks;
   tabcontent = document.getElementsByClassName("tabcontent");
   for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
   }
   tablinks = document.getElementsByClassName("tablinks");
   for (i = 0; i < tablinks.length; i++) {
       tablinks[i].className = tablinks[i].className.replace(" active", "");
   }
   document.getElementById(kategori).style.display = "block";
   evt.currentTarget.className += " active";
}

function rubahH1(){
browser.storage.sync.get([
   'setStatus'
]).then((item) => {
    
   var status = document.getElementById("setStatus")
   var ha1 = document.getElementsByTagName("h1")
   var tab = document.getElementsByClassName("tablinks")
    if(item.setStatus === "true" || status.value === "true"){
        ha1[0].style.background = "#04385e"
        tab[1].style.display = "block"
        tab[2].style.display = "block"
        tab[3].style.display = "block"
        tab[4].style.display = "block"
        document.getElementById("setNIP").parentNode.style.display = "block"
    }else{
        ha1[0].style.background = "#ae0202"
        tab[1].style.display = "none"
        tab[2].style.display = "none"
        tab[3].style.display = "none"
        tab[4].style.display = "none"
        document.getElementById("setNIP").parentNode.style.display = "none"
    }        
})
}

function mode(){
    browser.storage.sync.get([
   'setMode'
]).then((item) => {
   var status = document.getElementById("setMode")
   var ha1 = document.getElementsByTagName("h1")

   if(item.setMode === "penjagaan" || status.value === "penjagaan"){

        document.getElementById("setJamSiang").parentNode.style.display = "block"
        document.getElementById("setJamMalam").parentNode.style.display = "block"

    }else{
        document.getElementById("setJamSiang").parentNode.style.display = "none"
        document.getElementById("setJamMalam").parentNode.style.display = "none"
    }          
  })
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.querySelector('form').addEventListener('submit', saveOptions);
document.getElementById("setStatus").addEventListener("change", saveOptions);
document.getElementById("setMode").addEventListener("change", saveOptions);
document.getElementsByClassName("tablinks")[0].onclick = function(){tabDone(event, 'ke1')};
document.getElementsByClassName("tablinks")[1].onclick = function(){tabDone(event, 'ke2')};
document.getElementsByClassName("tablinks")[2].onclick = function(){tabDone(event, 'ke3')};
document.getElementsByClassName("tablinks")[3].onclick = function(){tabDone(event, 'ke4')};
document.getElementsByClassName("tablinks")[4].onclick = saveOptions;