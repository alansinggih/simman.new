function saveOptions(e) {

    // prefs object
    let data = {
        setStatus : document.querySelector('#setStatus').value  || 'true'
        ,setMode : document.querySelector('#setMode').value  || 'penjagaan'
        ,setNIP    : document.querySelector('#setNIP').value    || ''
        ,setPass : document.querySelector('#setPass').value || ''
        ,setJamPagi : document.querySelector('#setJamPagi').value || ''
        ,setJamSiang : document.querySelector('#setJamSiang').value || ''
        ,setJamMalam : document.querySelector('#setJamMalam').value || ''
        ,sisaSKP : document.querySelector('#sisaSKP').value || ''
        ,setSKP1 : document.querySelector('#setSKP1').value || ''
        ,setSKP2 : document.querySelector('#setSKP2').value || ''
        ,setSKP3 : document.querySelector('#setSKP3').value || ''
        ,setSKP4 : document.querySelector('#setSKP4').value || ''
        ,setSKP5 : document.querySelector('#setSKP5').value || ''
        ,setSKP6 : document.querySelector('#setSKP6').value || ''
        ,setSKP7 : document.querySelector('#setSKP7').value || ''
        ,setSKP8 : document.querySelector('#setSKP8').value || ''
        ,setSKP9 : document.querySelector('#setSKP9').value || ''
        ,setSKP10 : document.querySelector('#setSKP10').value || ''   
    }

    browser.storage.sync.set(data);

    // reload prefs
    browser.runtime.getBackgroundPage().then((item) => {
        item.simMan.loadData(function(){
            // refresh options
            restoreOptions();
            
        });
        
    });
    rubahH1()
    mode()
    e.preventDefault();    
    browser.tabs.query({currentWindow: true, active: true}).then((tabs) => {
        let tab = tabs[0]; // Safe to assume there will only be one result
        console.log(tab.url);
        browser.tabs.update({url: ''+tab.url+''})
        window.close()
    }, console.error), 

    window.close()
    
    
}

function restoreOptions() {
    browser.storage.sync.get('setStatus').then((item) => {
        document.querySelector('#setStatus').value = item.setStatus || '';
    });
    browser.storage.sync.get('setMode').then((item) => {
        document.querySelector('#setMode').value = item.setMode || '';
    });
    browser.storage.sync.get('setNIP').then((item) => {
        document.querySelector('#setNIP').value = item.setNIP || '';
    });
    browser.storage.sync.get('setPass').then((item) => {
        document.querySelector('#setPass').value = item.setPass || '';
    });
    browser.storage.sync.get('setJamPagi').then((item) => {
        document.querySelector('#setJamPagi').value = item.setJamPagi || '';
    });
    browser.storage.sync.get('setJamSiang').then((item) => {
        document.querySelector('#setJamSiang').value = item.setJamSiang || '';
    });
    browser.storage.sync.get('setJamMalam').then((item) => {
        document.querySelector('#setJamMalam').value = item.setJamMalam || '';
    });
    browser.storage.sync.get('sisaSKP').then((item) => {
        document.querySelector('#sisaSKP').value = item.sisaSKP || '';
    });
    browser.storage.sync.get('setSKP1').then((item) => {
        document.querySelector('#setSKP1').value = item.setSKP1 || '';
    });
    browser.storage.sync.get('setSKP2').then((item) => {
        document.querySelector('#setSKP2').value = item.setSKP2 || '';
    });
    browser.storage.sync.get('setSKP3').then((item) => {
        document.querySelector('#setSKP3').value = item.setSKP3 || '';
    });
    browser.storage.sync.get('setSKP4').then((item) => {
        document.querySelector('#setSKP4').value = item.setSKP4 || '';
    });
    browser.storage.sync.get('setSKP5').then((item) => {
        document.querySelector('#setSKP5').value = item.setSKP5 || '';
    });
    browser.storage.sync.get('setSKP6').then((item) => {
        document.querySelector('#setSKP6').value = item.setSKP6 || '';
    });
    browser.storage.sync.get('setSKP7').then((item) => {
        document.querySelector('#setSKP7').value = item.setSKP7 || '';
    });
    browser.storage.sync.get('setSKP8').then((item) => {
        document.querySelector('#setSKP8').value = item.setSKP8 || '';
    });
    browser.storage.sync.get('setSKP9').then((item) => {
        document.querySelector('#setSKP9').value = item.setSKP9 || '';
    });
    browser.storage.sync.get('setSKP10').then((item) => {
        document.querySelector('#setSKP10').value = item.setSKP10 || '';
    });
    
    browser.storage.sync.get('setLabel0').then((item) => {
        document.querySelector('#setLabel0').innerHTML = item.setLabel0 || '';
    });
        browser.storage.sync.get('setLabel1').then((item) => {
        document.querySelector('#setLabel1').innerHTML = item.setLabel1 || '';
    });
        browser.storage.sync.get('setLabel2').then((item) => {
        document.querySelector('#setLabel2').innerHTML = item.setLabel2 || '';
    });
        browser.storage.sync.get('setLabel3').then((item) => {
        document.querySelector('#setLabel3').innerHTML = item.setLabel3 || '';
    });
        browser.storage.sync.get('setLabel4').then((item) => {
        document.querySelector('#setLabel4').innerHTML = item.setLabel4 || '';
    });
        browser.storage.sync.get('setLabel5').then((item) => {
        document.querySelector('#setLabel5').innerHTML = item.setLabel5 || '';
    });
        browser.storage.sync.get('setLabel6').then((item) => {
        document.querySelector('#setLabel6').innerHTML = item.setLabel6 || '';
    });
        browser.storage.sync.get('setLabel7').then((item) => {
        document.querySelector('#setLabel7').innerHTML = item.setLabel7 || '';
    });
        browser.storage.sync.get('setLabel8').then((item) => {
        document.querySelector('#setLabel8').innerHTML = item.setLabel8 || '';
    });
        browser.storage.sync.get('setLabel9').then((item) => {
        document.querySelector('#setLabel9').innerHTML = item.setLabel9 || '';
    });

    rubahH1()
    mode()
}

function tabDone(evt, kategori) {
   var i, tabcontent, tablinks;
   tabcontent = document.getElementsByClassName("tabcontent");
   for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
   }
   tablinks = document.getElementsByClassName("tablinks");
   for (i = 0; i < tablinks.length; i++) {
       tablinks[i].className = tablinks[i].className.replace(" active", "");
   }
   document.getElementById(kategori).style.display = "block";
   evt.currentTarget.className += " active";
}

function rubahH1(){
browser.storage.sync.get([
   'setStatus'
]).then((item) => {
    
   var status = document.getElementById("setStatus")
   var ha1 = document.getElementsByTagName("h1")
   var tab = document.getElementsByClassName("tablinks")
    if(item.setStatus === "true" || status.value === "true"){
        ha1[0].style.background = "#04385e"
        tab[1].style.display = "block"
        tab[2].style.display = "block"
        tab[3].style.display = "block"
        tab[4].style.display = "block"
        document.getElementById("setNIP").parentNode.style.display = "block"
    }else{
        ha1[0].style.background = "#ae0202"
        tab[1].style.display = "none"
        tab[2].style.display = "none"
        tab[3].style.display = "none"
        tab[4].style.display = "none"
        document.getElementById("setNIP").parentNode.style.display = "none"
    }        
})
}

function mode(){
    browser.storage.sync.get([
   'setMode'
]).then((item) => {
   var status = document.getElementById("setMode")
   var ha1 = document.getElementsByTagName("h1")

   if(item.setMode === "penjagaan" || status.value === "penjagaan"){

        document.getElementById("setJamSiang").parentNode.style.display = "block"
        document.getElementById("setJamMalam").parentNode.style.display = "block"

    }else{
        document.getElementById("setJamSiang").parentNode.style.display = "none"
        document.getElementById("setJamMalam").parentNode.style.display = "none"
    }          
  })
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.querySelector('form').addEventListener('submit', saveOptions);
document.getElementById("setStatus").addEventListener("change", saveOptions);
document.getElementById("setMode").addEventListener("change", saveOptions);
document.getElementsByClassName("tablinks")[0].onclick = function(){tabDone(event, 'ke1')};
document.getElementsByClassName("tablinks")[1].onclick = function(){tabDone(event, 'ke2')};
document.getElementsByClassName("tablinks")[2].onclick = function(){tabDone(event, 'ke3')};
document.getElementsByClassName("tablinks")[3].onclick = function(){tabDone(event, 'ke4')};
document.getElementsByClassName("tablinks")[4].onclick = saveOptions;